/∗
<generator>
	<handlers doGet=”do hello”/>
</generator>
∗/

/∗ simple contents generator ∗/
static char do hello(struct args t ∗args) {
	out str(”Generated Hello World!”);
	return 1 ; 
}
