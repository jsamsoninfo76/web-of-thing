/*
<generator>
	<handlers doGet="doGet"/>
</generator>
*/

/* simple contents generator */
static char doGet(struct args_t *args) {
	rflpc_led_init();
	rflpc_led_set(RFLPC_LED_1);
	/*out_str("Generated Hello World ! ");*/
	return 1;
}
