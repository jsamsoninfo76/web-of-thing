#include <stdio.h>

extern char out_c(char c);
extern void hello_smews(void);

/*-----------------------------------------------------------------------------------*/
int main(void) {
	
	hello_smews();

	return 0;
}
