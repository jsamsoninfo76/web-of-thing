/*
* This file has been enriched by GenApps, a tool of the smews project
* smews home page: http://www.lifl.fr/2XS/smews
* Generation date: Wed Nov  7 06:51:33 2012
*/

#include "generators.h"
#include "stddef.h"

#include "defines.h"


/********** Output handler **********/
static generator_init_func_t init;
static generator_doget_func_t doGet;
CONST_VAR(struct output_handler_t, apps_examples_demo6_demo) = {
	.handler_type = type_generator,
	.handler_comet = 1,
	.handler_stream = 0,
	.handler_data = {
		.generator = {
			.prop = prop_volatile,
			.init = init,
			.handlers = {
				.get = {
					.doget = doGet,
				},
			},
		},
	},
#ifndef DISABLE_ARGS
	.handler_args = {
		.args_tree = NULL,
		.args_index = NULL,
		.args_size = 0
	},
#endif
#ifndef DISABLE_POST
	.handler_mimes = {
		.mimes_index = NULL,
		.mimes_size = 0,
	},
#endif
};

/* End of the enriched part */

/*
<generator>
	<handlers init="init" doGet="doGet"/>
	<properties persistence="volatile" interaction="stream" channel="myStreamedComet"/>
</generator>
*/

#include "generators.h"
#include "timers.h"
#include "channels.h"

/* timer callback function */
static void timer() {
	/* triggers the channel */
	server_push(&myStreamedComet);
}

static char init(void) {
	/* initilize a timer with a period of 1000 milliseconds */
	return set_timer(&timer,1000);
}

static char doGet(struct args_t *args) {
	/* outputs the current time in milliseconds */
	out_uint(TIME_MILLIS);
	return 1;
}
