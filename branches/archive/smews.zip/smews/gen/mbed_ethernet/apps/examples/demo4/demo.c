/*
* This file has been enriched by GenApps, a tool of the smews project
* smews home page: http://www.lifl.fr/2XS/smews
* Generation date: Wed Nov  7 07:31:46 2012
*/

#include "generators.h"
#include "stddef.h"

#include "defines.h"

#ifndef DISABLE_ARGS
/********** Arguments structure **********/
struct args_t {
	uint8_t i1;
	char s[6];
	uint16_t i2;
};

/********** Arguments index **********/
static CONST_VAR(struct arg_ref_t, args_index[]) = {
	{arg_type: arg_ui8, arg_size: sizeof(uint8_t), arg_offset: offsetof(struct args_t,i1)},
	{arg_type: arg_str, arg_size: sizeof(char[6]), arg_offset: offsetof(struct args_t,s)},
	{arg_type: arg_ui16, arg_size: sizeof(uint16_t), arg_offset: offsetof(struct args_t,i2)},
};

/********** Symbols list, total length: 5 bytes **********/
/*
* i1
* s
* i2
*/

/********** Generated Ternary Tree **********/
/*
* -s|END
* -<i2|END
* ---<1|END
*/

/********** "Understoodable" Generated BLOB, total length: 10 bytes **********/
/*
* "s",ref:1,<,"i2",ref:2,<,"1",ref:0,0
*/

/********** Finally Generated BLOB, total length: 10 bytes **********/
static CONST_VAR(unsigned char, args_tree[]) = {115,129,1,105,50,130,1,49,128,0};
#endif

/********** Output handler **********/
static generator_doget_func_t doGet;
CONST_VAR(struct output_handler_t, apps_examples_demo4_demo) = {
	.handler_type = type_generator,
	.handler_comet = 0,
	.handler_stream = 0,
	.handler_data = {
		.generator = {
			.prop = prop_persistent,
			.init = NULL,
			.handlers = {
				.get = {
					.doget = doGet,
				},
			},
		},
	},
#ifndef DISABLE_ARGS
	.handler_args = {
		.args_tree = args_tree,
		.args_index = args_index,
		.args_size = sizeof(struct args_t)
	},
#endif
#ifndef DISABLE_POST
	.handler_mimes = {
		.mimes_index = NULL,
		.mimes_size = 0,
	},
#endif
};

/* End of the enriched part */

/*
<generator>
	<handlers doGet="doGet"/>
	<args>
		<arg name="i1" type="uint8" />
		<arg name="s" type="str" size="6" />
		<arg name="i2" type="uint16" />
	</args>
</generator>
*/

static char doGet(struct args_t *args) {
	if(args) {
		out_str("first int : ");
		out_uint(args->i1);
		out_str("\nstr : ");
		out_str(args->s);
		out_str("\nsecond int : ");
		out_uint(args->i2);
	} else {
		out_str("no args");
	}
	return 1;
}
