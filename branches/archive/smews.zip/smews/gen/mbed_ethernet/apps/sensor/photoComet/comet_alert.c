/*
* This file has been enriched by GenApps, a tool of the smews project
* smews home page: http://www.lifl.fr/2XS/smews
* Generation date: Wed Nov  7 08:48:54 2012
*/

#include "generators.h"
#include "stddef.h"

#include "defines.h"

#ifndef DISABLE_ARGS
/********** Arguments structure **********/
struct args_t {
	uint16_t thres;
};

/********** Arguments index **********/
static CONST_VAR(struct arg_ref_t, args_index[]) = {
	{arg_type: arg_ui16, arg_size: sizeof(uint16_t), arg_offset: offsetof(struct args_t,thres)},
};

/********** Symbols list, total length: 5 bytes **********/
/*
* thres
*/

/********** Generated Ternary Tree **********/
/*
* -thres|END
*/

/********** "Understoodable" Generated BLOB, total length: 7 bytes **********/
/*
* "thres",ref:0,0
*/

/********** Finally Generated BLOB, total length: 7 bytes **********/
static CONST_VAR(unsigned char, args_tree[]) = {116,104,114,101,115,128,0};
#endif

/********** Output handler **********/
static generator_init_func_t init;
static generator_initget_func_t initGet;
static generator_doget_func_t doGet;
CONST_VAR(struct output_handler_t, apps_sensor_photoComet_comet_alert) = {
	.handler_type = type_generator,
	.handler_comet = 1,
	.handler_stream = 0,
	.handler_data = {
		.generator = {
			.prop = prop_volatile,
			.init = init,
			.handlers = {
				.get = {
				.initget = initGet,
					.doget = doGet,
				},
			},
		},
	},
#ifndef DISABLE_ARGS
	.handler_args = {
		.args_tree = args_tree,
		.args_index = args_index,
		.args_size = sizeof(struct args_t)
	},
#endif
#ifndef DISABLE_POST
	.handler_mimes = {
		.mimes_index = NULL,
		.mimes_size = 0,
	},
#endif
};

/* End of the enriched part */

/*
* Copyright or © or Copr. 2008, Simon Duquennoy
* 
* Author e-mail: simon.duquennoy@lifl.fr
* 
* This software is a computer program whose purpose is to design an
* efficient Web server for very-constrained embedded system.
* 
* This software is governed by the CeCILL license under French law and
* abiding by the rules of distribution of free software.  You can  use, 
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info". 
* 
* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability. 
* 
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or 
* data to be ensured and,  more generally, to use and operate it in the 
* same conditions as regards security. 
* 
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
*/

/*
<generator>
	<handlers init="init" initGet="initGet" doGet="doGet"/>
	<properties persistence="volatile" interaction="alert" channel="alertChannel"/>
	<args>
		<arg name="thres" type="uint16" />
	</args>
</generator>
*/

#include "generators.h"
#include "timers.h"
#include "channels.h"

static int threshold = 512;

static int16_t glob_sample;

static void timer() {
	int16_t tmp_result = GetADCVal(ADC_LIGHT);
	if(tmp_result < threshold) {
		glob_sample = tmp_result;
		server_push(&alertChannel);
	}
}

static char init(void) {
	return initADC(ADC_LIGHT) && set_timer(&timer,100);
}

static char initGet(struct args_t *args) {
	if(args)
		threshold = args->thres;
	return 1;
}

static char doGet(struct args_t *args) {
	out_uint(glob_sample);
	return 1;
}
