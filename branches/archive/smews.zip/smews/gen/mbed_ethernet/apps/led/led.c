/*
* This file has been enriched by GenApps, a tool of the smews project
* smews home page: http://www.lifl.fr/2XS/smews
* Generation date: Thu Nov  8 06:16:26 2012
*/

#include "generators.h"
#include "stddef.h"

#include "defines.h"

#ifndef DISABLE_ARGS
/********** Arguments structure **********/
struct args_t {
	uint8_t nled;
	uint8_t etat;
};

/********** Arguments index **********/
static CONST_VAR(struct arg_ref_t, args_index[]) = {
	{arg_type: arg_ui8, arg_size: sizeof(uint8_t), arg_offset: offsetof(struct args_t,nled)},
	{arg_type: arg_ui8, arg_size: sizeof(uint8_t), arg_offset: offsetof(struct args_t,etat)},
};

/********** Symbols list, total length: 8 bytes **********/
/*
* nled
* etat
*/

/********** Generated Ternary Tree **********/
/*
* -n
* -=led|END
* -<etat|END
*/

/********** "Understoodable" Generated BLOB, total length: 14 bytes **********/
/*
* "n",<=,=:6,"etat",ref:1,0,"led",ref:0,0
*/

/********** Finally Generated BLOB, total length: 14 bytes **********/
static CONST_VAR(unsigned char, args_tree[]) = {110,3,6,101,116,97,116,129,0,108,101,100,128,0};
#endif

/********** Output handler **********/
static generator_doget_func_t doGet;
CONST_VAR(struct output_handler_t, apps_led_led) = {
	.handler_type = type_generator,
	.handler_comet = 0,
	.handler_stream = 0,
	.handler_data = {
		.generator = {
			.prop = prop_persistent,
			.init = NULL,
			.handlers = {
				.get = {
					.doget = doGet,
				},
			},
		},
	},
#ifndef DISABLE_ARGS
	.handler_args = {
		.args_tree = args_tree,
		.args_index = args_index,
		.args_size = sizeof(struct args_t)
	},
#endif
#ifndef DISABLE_POST
	.handler_mimes = {
		.mimes_index = NULL,
		.mimes_size = 0,
	},
#endif
};

/* End of the enriched part */

/*
<generator>
	<handlers doGet="doGet"/>
	<args>
		<arg name="nled" type="uint8" />
		<arg name="etat" type="uint8" />
	</args>
</generator>
*/

#include <rflpc17xx/rflpc17xx.h>

static char doGet(struct args_t *args){
	rflpc_led_init() ;
	
	switch (args->nled)
	{
		case 0: 
			if (args->etat == 1) rflpc_led_set(RFLPC_LED_1);
			else rflpc_led_clr(RFLPC_LED_1);
			break;
		case 1: 
			if (args->etat == 1) rflpc_led_set(RFLPC_LED_2);
			else rflpc_led_clr(RFLPC_LED_2);
			break;
		case 2: 
			if (args->etat == 1) rflpc_led_set(RFLPC_LED_3);
			else rflpc_led_clr(RFLPC_LED_3);
			break;
		case 3: 
			if (args->etat == 1) rflpc_led_set(RFLPC_LED_4);
			else rflpc_led_clr(RFLPC_LED_4);
			break;
	} 
	

	return 0 ;
}
