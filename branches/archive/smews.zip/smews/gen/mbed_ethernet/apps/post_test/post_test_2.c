/*
* This file has been enriched by GenApps, a tool of the smews project
* smews home page: http://www.lifl.fr/2XS/smews
* Generation date: Wed Nov  7 07:42:54 2012
*/

#include "generators.h"
#include "stddef.h"

#include "defines.h"

#ifndef DISABLE_POST
/********* Content-types array **********/
static CONST_VAR(unsigned char, mimes_index[]) = {NULL};

#endif

/********** Output handler **********/
static generator_dopost_out_func_t doPostOut;
static generator_dopost_in_func_t doPostIn;
CONST_VAR(struct output_handler_t, apps_post_test_post_test_2) = {
	.handler_type = type_generator,
	.handler_comet = 0,
	.handler_stream = 0,
	.handler_data = {
		.generator = {
			.prop = prop_persistent,
			.init = NULL,
			.handlers = {
				.post = {
					.dopostin = doPostIn,
					.dopostout = doPostOut,
				},
			},
		},
	},
#ifndef DISABLE_ARGS
	.handler_args = {
		.args_tree = NULL,
		.args_index = NULL,
		.args_size = 0
	},
#endif
#ifndef DISABLE_POST
	.handler_mimes = {
		.mimes_index = NULL,
		.mimes_size = 0,
	},
#endif
};

/* End of the enriched part */

/*
<generator>
	<handlers doPostOut="doPostOut" doPostIn="doPostIn"/>
	<content-types>
	</content-types>
</generator>
*/

static char doPostIn(uint8_t content_type, uint8_t part_number, char *filename, void **post_data) {
	uint8_t i = 0;
	short value;

	/* too many files (only 1 managed) */
	if(part_number > 1)
		return 1;

	/* allocating files structure if necessary */
	if(!*post_data){
		*post_data = mem_alloc(100 * sizeof(char));
		if(!*post_data)
			return 1;
	}

	i = 0;
	while((value = in()) != -1 && i < 99)
		((char *)*post_data)[i++] = value;
	((char *)*post_data)[i++] = '\0';

	/* test return -1 */
	in();	
	in();	
	in();	

	out_str("To test wrong usage\n"); // never called

	return 1;
}

static char doPostOut(uint8_t content_type, void *post_data) {
 	if(post_data){
		out_str((char *)post_data);
		mem_free(post_data,100 * sizeof(char));
	}
	else
		out_str("No data file");

	in(); // never called
	return 1;
}
