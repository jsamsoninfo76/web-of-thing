#$ scons target=WSN430 apps=:welcome,sensor ipaddr=192.168.1.2
#Installation, i.e. copy of the code in the EEPROM of the WSN430 board (as root):
#$ ./targets/WSN430/install
#PanManager conguration (as root, in panManager folder):
#$ bin/panManager slip 192.168.1.1/24

if test -z "$1" 
then
	echo "Il faut une variable"
else
	scons target=mbed_ethernet apps=:$1 ipaddr=192.168.0.20
	cp /Users/Spider/Downloads/PJE/smews/bin/mbed_ethernet/smews.bin /Volumes/MBED/
fi
