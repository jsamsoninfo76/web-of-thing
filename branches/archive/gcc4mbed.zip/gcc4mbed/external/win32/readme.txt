The subversion binaries in this directory were downloaded from http://www.sliksvn.com/en/download
The patch binaries in this directory were downloaded from http://gnuwin32.sourceforge.net/packages/patch.htm
The bsdtar binaries in this directory were downloaded from http://gnuwin32.sourceforge.net/packages/libarchive.htm
The curl binaries in this directory were downloaded from http://curl.haxx.se/download.html
The md5sum binaries in this directory were downloaded from http://gnuwin32.sourceforge.net/packages/coreutils.htm
The make binaries in this directory were downloaded from http://gnuwin32.sourceforge.net/packages/make.htm